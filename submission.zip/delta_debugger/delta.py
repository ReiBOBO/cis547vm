import math

from typing import Tuple

from delta_debugger import run_target

EMPTY_STRING = b"haha"

def delta_debug(target: str, input: bytes) -> bytes:
    global EMPTY_STRING
    """
    Delta-Debugging algorithm

    TODO: Implement your algorithm for delta-debugging.

    Hint: It may be helpful to use an auxilary function that
    takes as input a target, input string, n and
    returns the next input and n to try.

    :param target: target program
    :param input: crashing input to be minimized
    :return: 1-minimal crashing input.
    """
    
    EMPTY_STRING = input
    helper(target,input,2)
    return EMPTY_STRING
#helper function that runs the actual minimization algorithm

def helper(target, input:bytes, n:int ):
    global EMPTY_STRING
    length = len(input)
    if(length<n):
        if(run_target(target,b"")!=0):
            EMPTY_STRING=b""
        return 
    x:int = 0
    while(x<length):
        start:int = x
        x=x+int(length/n)
        delta=input[start:x]
        dabla=input[0:start]+input[x:length]
        passed=run_target(target,delta)
        if(passed!=0): #failed good
            if(len(EMPTY_STRING)>len(delta)):
                EMPTY_STRING=delta
            helper(target,delta,2)
            return
        else:        
            passed=run_target(target,dabla)
            if(passed!=0):
                if(len(EMPTY_STRING)>len(dabla)): 
                    EMPTY_STRING=dabla
                helper(target,dabla,n-1)
                return
    if(passed==0):
        helper(target,input,n*2)  
    
    
    